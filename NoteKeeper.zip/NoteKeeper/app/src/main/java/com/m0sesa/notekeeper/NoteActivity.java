package com.m0sesa.notekeeper;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.EditText;

public class NoteActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final String TAG = "NoteActivity";

    public static final String NOTE_ID = "note_id";
    public static final int NO_NOTE = -1;
    public static final int NOTE_CURSOR_LOADER = 0;
    Cursor cursor;
    private int noteId;
    EditText noteBody, noteTitle;

    NotesDatabaseOpenHelper notesDatabaseOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        noteTitle = findViewById(R.id.note_title);
        noteBody = findViewById(R.id.note_body);

        Intent intent = getIntent();
        noteId = intent.getIntExtra(NOTE_ID, NO_NOTE);

        notesDatabaseOpenHelper = new NotesDatabaseOpenHelper(this);

        prepareActivity();
    }

    private void prepareActivity() {
        getSupportLoaderManager().initLoader(NOTE_CURSOR_LOADER, null, this);
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int i, @Nullable Bundle bundle) {
        CursorLoader loader = null;
        if (i== NOTE_CURSOR_LOADER){
            loader = loadNote();
        }
        return loader;
    }

    private CursorLoader loadNote() {
        return new CursorLoader(this){
            @Override
            public Cursor loadInBackground() {
                SQLiteDatabase db = notesDatabaseOpenHelper.getReadableDatabase();

                String selection = DatabaseContract.NotesTable._ID + " = ?";
                String[] selectionArgs = {String.valueOf(noteId)};

                return db.query(DatabaseContract.NotesTable.TABLE_NAME, null, selection, selectionArgs,
                        null, null, null);
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor cursor) {
        this.cursor = cursor;
        cursor.moveToFirst();
        noteTitle.setText(cursor.getString(cursor.getColumnIndex(DatabaseContract.NotesTable.NOTE_TITLE)));
        noteBody.setText(cursor.getString(cursor.getColumnIndex(DatabaseContract.NotesTable.NOTE_BODY)));
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        cursor.close();
    }

    @Override
    protected void onDestroy() {
        notesDatabaseOpenHelper.close();
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
